/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2019 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.3.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "defs.y" /* yacc.c:337  */

#include <stdio.h>
#include <string.h>

#ifdef WIN32

// void * _alloca( size_t ) ;
#define alloca _alloca

#endif /* WIN32 */

#include <stdlib.h>
#include "tree.h"
#include "dealer.h"

void  yyerror (char*);
void  setshapebit (int, int, int, int, int, int);
void  predeal (int, card);
card  make_card(char,char);
void  clearpointcount(void);
void  clearpointcount_alt(int);
void  pointcount(int,int);
void* mycalloc(int,size_t);
int   make_contract (char, char);

int predeal_compass;     /* global variable for predeal communication */

int pointcount_index;    /* global variable for pointcount communication */

int shapeno ;

struct tree *var_lookup(char *s, int mustbethere) ;
struct action *newaction(int type, struct tree * p1, char * s1, int, struct tree * ) ;
struct tree *newtree (int, struct tree*, struct tree*, int, int);
struct expr  *newexpr(struct tree* tr1, char* ch1, struct expr* ex1);
void bias_deal(int suit, int compass, int length) ;
void predeal_holding(int compass, char *holding) ;
void insertshape(char s[4], int any, int neg_shape) ;
void new_var(char *s, struct tree *t) ;

#line 111 "y.tab.c" /* yacc.c:337  */
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif


/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    QUERY = 258,
    COLON = 259,
    OR2 = 260,
    AND2 = 261,
    CMPEQ = 262,
    CMPNE = 263,
    CMPLT = 264,
    CMPLE = 265,
    CMPGT = 266,
    CMPGE = 267,
    ARPLUS = 268,
    ARMINUS = 269,
    ARTIMES = 270,
    ARDIVIDE = 271,
    ARMOD = 272,
    NOT = 273,
    GENERATE = 274,
    PRODUCE = 275,
    HCP = 276,
    SHAPE = 277,
    ANY = 278,
    EXCEPT = 279,
    CONDITION = 280,
    ACTION = 281,
    PRINT = 282,
    PRINTALL = 283,
    PRINTEW = 284,
    PRINTPBN = 285,
    PRINTCOMPACT = 286,
    PRINTONELINE = 287,
    AVERAGE = 288,
    HASCARD = 289,
    FREQUENCY = 290,
    PREDEAL = 291,
    POINTCOUNT = 292,
    ALTCOUNT = 293,
    CONTROL = 294,
    LOSER = 295,
    DEALER = 296,
    QUALITY = 297,
    CCCC = 298,
    TRICKS = 299,
    NOTRUMPS = 300,
    NORTHSOUTH = 301,
    EASTWEST = 302,
    EVALCONTRACT = 303,
    ALL = 304,
    NONE = 305,
    SCORE = 306,
    IMPS = 307,
    RND = 308,
    PT0 = 309,
    PT1 = 310,
    PT2 = 311,
    PT3 = 312,
    PT4 = 313,
    PT5 = 314,
    PT6 = 315,
    PT7 = 316,
    PT8 = 317,
    PT9 = 318,
    PRINTES = 319,
    NUMBER = 320,
    HOLDING = 321,
    STRING = 322,
    IDENT = 323,
    COMPASS = 324,
    VULNERABLE = 325,
    VULN = 326,
    SUIT = 327,
    CARD = 328,
    CONTRACT = 329,
    DISTR = 330,
    DISTR_OR_NUMBER = 331
  };
#endif
/* Tokens.  */
#define QUERY 258
#define COLON 259
#define OR2 260
#define AND2 261
#define CMPEQ 262
#define CMPNE 263
#define CMPLT 264
#define CMPLE 265
#define CMPGT 266
#define CMPGE 267
#define ARPLUS 268
#define ARMINUS 269
#define ARTIMES 270
#define ARDIVIDE 271
#define ARMOD 272
#define NOT 273
#define GENERATE 274
#define PRODUCE 275
#define HCP 276
#define SHAPE 277
#define ANY 278
#define EXCEPT 279
#define CONDITION 280
#define ACTION 281
#define PRINT 282
#define PRINTALL 283
#define PRINTEW 284
#define PRINTPBN 285
#define PRINTCOMPACT 286
#define PRINTONELINE 287
#define AVERAGE 288
#define HASCARD 289
#define FREQUENCY 290
#define PREDEAL 291
#define POINTCOUNT 292
#define ALTCOUNT 293
#define CONTROL 294
#define LOSER 295
#define DEALER 296
#define QUALITY 297
#define CCCC 298
#define TRICKS 299
#define NOTRUMPS 300
#define NORTHSOUTH 301
#define EASTWEST 302
#define EVALCONTRACT 303
#define ALL 304
#define NONE 305
#define SCORE 306
#define IMPS 307
#define RND 308
#define PT0 309
#define PT1 310
#define PT2 311
#define PT3 312
#define PT4 313
#define PT5 314
#define PT6 315
#define PT7 316
#define PT8 317
#define PT9 318
#define PRINTES 319
#define NUMBER 320
#define HOLDING 321
#define STRING 322
#define IDENT 323
#define COMPASS 324
#define VULNERABLE 325
#define VULN 326
#define SUIT 327
#define CARD 328
#define CONTRACT 329
#define DISTR 330
#define DISTR_OR_NUMBER 331

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 43 "defs.y" /* yacc.c:352  */

        int     y_int;
        char    *y_str;
        struct tree *y_tree;
        struct action *y_action;
        struct expr   *y_expr;
        char    y_distr[4];

#line 312 "y.tab.c" /* yacc.c:352  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);





#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && ! defined __ICC && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   574

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  81
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  25
/* YYNRULES -- Number of rules.  */
#define YYNRULES  120
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  292

#define YYUNDEFTOK  2
#define YYMAXUTOK   331

/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                                \
  ((unsigned) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      78,    79,     2,     2,    80,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    77,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   145,   145,   147,   151,   153,   155,   159,   163,   164,
     164,   166,   165,   167,   169,   171,   173,   178,   179,   183,
     183,   184,   188,   190,   194,   197,   196,   204,   209,   214,
     216,   219,   220,   226,   227,   233,   234,   236,   241,   242,
     245,   250,   251,   255,   257,   259,   261,   263,   265,   267,
     269,   271,   273,   275,   277,   279,   281,   283,   285,   287,
     289,   291,   293,   295,   297,   299,   301,   303,   305,   307,
     309,   311,   313,   315,   317,   325,   327,   329,   331,   333,
     335,   337,   339,   341,   343,   345,   347,   349,   351,   353,
     355,   357,   359,   361,   363,   365,   367,   372,   374,   376,
     378,   383,   385,   388,   391,   395,   399,   403,   406,   409,
     412,   415,   418,   421,   424,   426,   430,   441,   442,   446,
     448
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "QUERY", "COLON", "OR2", "AND2", "CMPEQ",
  "CMPNE", "CMPLT", "CMPLE", "CMPGT", "CMPGE", "ARPLUS", "ARMINUS",
  "ARTIMES", "ARDIVIDE", "ARMOD", "NOT", "GENERATE", "PRODUCE", "HCP",
  "SHAPE", "ANY", "EXCEPT", "CONDITION", "ACTION", "PRINT", "PRINTALL",
  "PRINTEW", "PRINTPBN", "PRINTCOMPACT", "PRINTONELINE", "AVERAGE",
  "HASCARD", "FREQUENCY", "PREDEAL", "POINTCOUNT", "ALTCOUNT", "CONTROL",
  "LOSER", "DEALER", "QUALITY", "CCCC", "TRICKS", "NOTRUMPS", "NORTHSOUTH",
  "EASTWEST", "EVALCONTRACT", "ALL", "NONE", "SCORE", "IMPS", "RND", "PT0",
  "PT1", "PT2", "PT3", "PT4", "PT5", "PT6", "PT7", "PT8", "PT9", "PRINTES",
  "NUMBER", "HOLDING", "STRING", "IDENT", "COMPASS", "VULNERABLE", "VULN",
  "SUIT", "CARD", "CONTRACT", "DISTR", "DISTR_OR_NUMBER", "'='", "'('",
  "')'", "','", "$accept", "defs", "def", "$@1", "$@2", "predealargs",
  "predealarg", "$@3", "holdings", "pointcountargs", "$@4", "compass",
  "vulnerable", "shlprefix", "any", "number", "shape", "shapelistel",
  "shapelist", "expr", "exprlist", "actionlist", "action", "optstring",
  "printlist", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,    61,    40,    41,
      44
};
# endif

#define YYPACT_NINF -101

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-101)))

#define YYTABLE_NINF -1

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    -101,   138,  -101,   -27,   453,    10,    10,   -38,    -7,   453,
     326,     9,   -46,  -101,    10,    34,    41,   133,    58,    77,
     129,   137,   203,   241,   260,   274,   282,   284,   288,   290,
     291,   297,   298,   299,  -101,    37,   147,   300,  -101,   453,
    -101,  -101,   541,  -101,  -101,  -101,  -101,  -101,   133,   133,
     541,   302,  -101,  -101,  -101,   303,   304,   305,   305,  -101,
     306,  -101,   307,   310,  -101,   308,   -46,  -101,    10,  -101,
     133,   133,  -101,  -101,   133,   133,   133,   314,   453,   453,
     133,   133,   133,   133,   133,   133,   133,   133,   133,   133,
     453,  -101,  -101,   133,   134,   453,   453,   453,   453,   453,
     453,   453,   453,   453,   453,   453,   453,   453,   453,    -6,
     315,   325,   453,   453,  -101,   453,   318,   349,   326,   317,
     333,   351,  -101,  -101,  -101,    10,    38,    74,   338,   345,
     346,   348,   219,   244,    82,    86,    89,    91,   104,   106,
     108,   125,   132,   139,   541,   350,  -101,   118,   279,   552,
     229,    19,    45,   301,    67,    51,    75,    92,   204,   413,
    -101,  -101,   359,    -8,  -101,   198,   294,   319,   541,   453,
    -101,   541,   200,  -101,   360,  -101,   352,   355,    10,  -101,
    -101,   364,  -101,   365,   366,  -101,   -18,   368,  -101,  -101,
    -101,   367,  -101,   374,  -101,   375,  -101,   376,  -101,   377,
    -101,   378,  -101,   379,  -101,   393,  -101,   398,  -101,   400,
    -101,   453,   397,  -101,  -101,  -101,   455,  -101,   -10,  -101,
     411,  -101,  -101,     5,  -101,   401,   402,   416,   476,  -101,
     405,   406,   407,   409,   410,   414,   412,   419,   420,   423,
     424,   438,   440,   441,   445,   451,   258,  -101,  -101,   245,
    -101,  -101,  -101,    10,  -101,   541,  -101,  -101,   425,  -101,
    -101,  -101,  -101,  -101,   453,  -101,  -101,  -101,  -101,  -101,
    -101,  -101,  -101,  -101,  -101,  -101,  -101,  -101,   462,  -101,
     334,    10,  -101,   285,  -101,   453,    36,    10,   463,    10,
     491,  -101
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       2,     0,     1,     0,     0,     0,     0,     0,     0,     0,
     103,     0,     0,     9,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    35,    44,     0,     0,    37,     0,
       3,    43,    14,    36,    44,    95,     4,     5,     0,     0,
      13,     0,   104,   105,   109,   107,   108,   117,   117,   111,
       0,    16,   101,     0,    19,     0,     8,    17,    24,    11,
       0,     0,    27,     6,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    28,     7,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   118,     0,     0,     0,   103,     0,
       0,     0,    18,    10,    25,    24,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    15,     0,    80,     0,    88,    87,
      81,    82,    83,    84,    85,    86,    89,    90,    91,    92,
      93,    46,     0,    31,   119,     0,     0,     0,   114,     0,
      98,    97,     0,   102,     0,    22,    20,     0,    24,    12,
      70,     0,    68,     0,     0,    72,     0,     0,    79,    96,
      48,     0,    50,     0,    52,     0,    54,     0,    56,     0,
      58,     0,    60,     0,    62,     0,    64,     0,    66,     0,
      45,     0,     0,    30,    32,    29,    33,    41,    31,   106,
       0,   112,   113,     0,   110,     0,     0,     0,     0,    26,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    94,    47,    34,     0,
      74,    42,   120,     0,   100,    99,    75,    23,     0,    71,
      69,    73,    77,    76,     0,    49,    51,    53,    55,    57,
      59,    61,    63,    65,    67,    38,    39,    40,     0,    21,
       0,     0,    78,     0,   115,     0,     0,     0,     0,     0,
       0,   116
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -101,  -101,  -101,  -101,  -101,  -101,   505,  -101,  -101,  -100,
    -101,   452,  -101,  -101,  -101,    -5,  -101,   354,  -101,    -2,
    -101,   456,  -101,   515,  -101
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,    40,    68,   125,    66,    67,   120,   176,   123,
     178,    73,    92,   216,   249,    41,   277,   217,   218,    42,
     172,    61,    62,   115,   165
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_uint16 yytable[] =
{
      46,    47,    45,   213,   214,   213,   214,    50,    95,    69,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,    64,     3,   179,    65,   233,   100,   101,
     102,   103,   104,   105,   106,   107,   108,    94,    43,    95,
      48,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   234,   101,   102,   103,   104,   105,
     106,   107,   108,   124,   104,   105,   106,   107,   108,   250,
     215,    49,   215,   161,   162,    34,   132,   133,   229,   103,
     104,   105,   106,   107,   108,   253,    38,    63,   144,   105,
     106,   107,   108,   147,   148,   149,   150,   151,   152,   153,
     154,   155,   156,   157,   158,   159,   160,   106,   107,   108,
     166,   167,    70,   168,    90,   171,   287,   180,   181,    71,
     124,    95,   211,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,    74,    95,     2,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,     3,   182,   183,    75,     4,     5,     6,     7,
       8,   190,   191,     9,    10,   192,   193,   223,   194,   195,
     196,   197,    11,   124,    12,    13,    14,    15,    16,    17,
      18,    19,    20,   198,   199,   200,   201,   202,   203,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    72,    34,   204,   205,    35,    76,    36,   246,
      37,   206,   207,   146,    38,    77,    39,    91,   208,   209,
     107,   108,    95,   255,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,    95,   278,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   280,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   283,   219,   220,   224,
     225,    78,   288,   286,   290,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,    95,   188,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   102,   103,   104,   105,   106,   107,   108,    79,
     275,   276,    95,   189,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,    95,    80,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,    81,    51,    52,    53,    54,    55,    56,    57,
      82,    58,    83,     3,   284,   285,    84,     4,    85,    86,
       7,     8,   114,   221,    59,    87,    88,    89,    93,   119,
     111,   112,   113,    11,   117,   131,   121,   118,    15,    16,
      60,    18,    19,    20,   164,   163,   169,   174,   222,   175,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,   282,    34,     3,   170,    44,   184,     4,
     177,    37,     7,     8,   185,    38,   186,    39,   187,   210,
     108,   212,   227,   226,   228,    11,   230,   231,   232,   236,
      15,    16,   235,    18,    19,    20,   237,   238,   239,   240,
     241,   242,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,   243,    34,     3,   254,    44,
     244,     4,   245,    37,     7,     8,   247,    38,   248,    39,
     252,   256,   257,   258,   259,   260,   261,    11,   262,   263,
     279,   265,    15,    16,   264,    18,    19,    20,   266,   267,
     109,   110,   268,   269,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,   270,    34,   271,
     272,    44,   126,   127,   273,    37,   128,   129,   130,    38,
     274,    39,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   281,   289,    95,   145,    96,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     291,   122,   251,   116,   173
};

static const yytype_uint16 yycheck[] =
{
       5,     6,     4,    13,    14,    13,    14,     9,     3,    14,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    69,    14,   125,    72,    45,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    39,    65,     3,
      78,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    72,    10,    11,    12,    13,    14,
      15,    16,    17,    68,    13,    14,    15,    16,    17,    79,
      80,    78,    80,    79,    80,    65,    78,    79,   178,    12,
      13,    14,    15,    16,    17,    80,    76,    78,    90,    14,
      15,    16,    17,    95,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,    15,    16,    17,
     112,   113,    78,   115,    77,   117,    80,    79,    80,    78,
     125,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    78,     3,     0,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    14,    79,    80,    78,    18,    19,    20,    21,
      22,    79,    80,    25,    26,    79,    80,   169,    79,    80,
      79,    80,    34,   178,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    79,    80,    79,    80,    79,    80,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    69,    65,    79,    80,    68,    78,    70,   211,
      72,    79,    80,    79,    76,    78,    78,    70,    79,    80,
      16,    17,     3,   225,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,     3,   253,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,   264,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,   281,    79,    80,    79,
      80,    78,   287,   285,   289,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,     3,    79,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    11,    12,    13,    14,    15,    16,    17,    78,
      75,    76,     3,    79,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,     3,    78,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    78,    27,    28,    29,    30,    31,    32,    33,
      78,    35,    78,    14,    79,    80,    78,    18,    78,    78,
      21,    22,    67,    79,    48,    78,    78,    78,    78,    69,
      78,    78,    78,    34,    78,    71,    78,    80,    39,    40,
      64,    42,    43,    44,    69,    80,    78,    80,    79,    66,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    79,    65,    14,    67,    68,    80,    18,
      69,    72,    21,    22,    79,    76,    80,    78,    80,    79,
      17,    72,    80,    73,    79,    34,    72,    72,    72,    72,
      39,    40,    74,    42,    43,    44,    72,    72,    72,    72,
      72,    72,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    72,    65,    14,    67,    68,
      72,    18,    72,    72,    21,    22,    79,    76,    23,    78,
      69,    79,    66,     7,    79,    79,    79,    34,    79,    79,
      65,    79,    39,    40,    80,    42,    43,    44,    79,    79,
      48,    49,    79,    79,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    79,    65,    79,
      79,    68,    70,    71,    79,    72,    74,    75,    76,    76,
      79,    78,    80,    81,    82,    83,    84,    85,    86,    87,
      88,    89,    80,    80,     3,    93,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      79,    66,   218,    58,   118
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    82,     0,    14,    18,    19,    20,    21,    22,    25,
      26,    34,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    65,    68,    70,    72,    76,    78,
      83,    96,   100,    65,    68,   100,    96,    96,    78,    78,
     100,    27,    28,    29,    30,    31,    32,    33,    35,    48,
      64,   102,   103,    78,    69,    72,    86,    87,    84,    96,
      78,    78,    69,    92,    78,    78,    78,    78,    78,    78,
      78,    78,    78,    78,    78,    78,    78,    78,    78,    78,
      77,    70,    93,    78,   100,     3,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    92,
      92,    78,    78,    78,    67,   104,   104,    78,    80,    69,
      88,    78,    87,    90,    96,    85,    92,    92,    92,    92,
      92,    71,   100,   100,    92,    92,    92,    92,    92,    92,
      92,    92,    92,    92,   100,    92,    79,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
     100,    79,    80,    80,    69,   105,   100,   100,   100,    78,
      67,   100,   101,   102,    80,    66,    89,    69,    91,    90,
      79,    80,    79,    80,    80,    79,    80,    80,    79,    79,
      79,    80,    79,    80,    79,    80,    79,    80,    79,    80,
      79,    80,    79,    80,    79,    80,    79,    80,    79,    80,
      79,     4,    72,    13,    14,    80,    94,    98,    99,    79,
      80,    79,    79,   100,    79,    80,    73,    80,    79,    90,
      72,    72,    72,    45,    72,    74,    72,    72,    72,    72,
      72,    72,    72,    72,    72,    72,   100,    79,    23,    95,
      79,    98,    69,    80,    67,   100,    79,    66,     7,    79,
      79,    79,    79,    79,    80,    79,    79,    79,    79,    79,
      79,    79,    79,    79,    79,    75,    76,    97,    96,    65,
     100,    80,    79,    96,    79,    80,   100,    80,    96,    80,
      96,    79
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    81,    82,    82,    83,    83,    83,    83,    83,    84,
      83,    85,    83,    83,    83,    83,    83,    86,    86,    88,
      87,    87,    89,    89,    90,    91,    90,    92,    93,    94,
      94,    94,    94,    95,    95,    96,    96,    96,    97,    97,
      98,    99,    99,   100,   100,   100,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   101,   101,   101,
     101,   102,   102,   102,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   104,   104,   105,
     105
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     2,     2,     2,     2,     2,     2,     0,
       3,     0,     4,     2,     1,     3,     2,     1,     2,     0,
       3,     6,     1,     3,     0,     0,     3,     1,     1,     1,
       1,     0,     1,     0,     1,     1,     2,     1,     1,     1,
       3,     1,     2,     1,     1,     4,     4,     6,     4,     6,
       4,     6,     4,     6,     4,     6,     4,     6,     4,     6,
       4,     6,     4,     6,     4,     6,     4,     6,     4,     6,
       4,     6,     4,     6,     6,     6,     6,     6,     8,     4,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     5,     2,     4,     1,     1,     3,
       3,     1,     3,     0,     1,     1,     4,     1,     1,     1,
       4,     1,     4,     4,     3,     9,    15,     0,     1,     1,
       3
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YYUSE (yyoutput);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyo, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyo, yytype, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &yyvsp[(yyi + 1) - (yynrhs)]
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return (YYSIZE_T) (yystpcpy (yyres, yystr) - yyres);
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
                    yysize = yysize1;
                  else
                    return 2;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
      yysize = yysize1;
    else
      return 2;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yynewstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  *yyssp = (yytype_int16) yystate;

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    goto yyexhaustedlab;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = (YYSIZE_T) (yyssp - yyss + 1);

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
# undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 4:
#line 152 "defs.y" /* yacc.c:1652  */
    { extern int maxgenerate; if(!maxgenerate) maxgenerate = (yyvsp[0].y_int); }
#line 1663 "y.tab.c" /* yacc.c:1652  */
    break;

  case 5:
#line 154 "defs.y" /* yacc.c:1652  */
    { extern int maxproduce; if(!maxproduce) maxproduce = (yyvsp[0].y_int); }
#line 1669 "y.tab.c" /* yacc.c:1652  */
    break;

  case 6:
#line 156 "defs.y" /* yacc.c:1652  */
    { extern int maxdealer;
                  maxdealer = (yyvsp[0].y_int);
                }
#line 1677 "y.tab.c" /* yacc.c:1652  */
    break;

  case 7:
#line 160 "defs.y" /* yacc.c:1652  */
    { extern int maxvuln;
                  maxvuln = (yyvsp[0].y_int);
                }
#line 1685 "y.tab.c" /* yacc.c:1652  */
    break;

  case 9:
#line 164 "defs.y" /* yacc.c:1652  */
    { clearpointcount(); pointcount_index=12;}
#line 1691 "y.tab.c" /* yacc.c:1652  */
    break;

  case 11:
#line 166 "defs.y" /* yacc.c:1652  */
    { clearpointcount_alt((yyvsp[0].y_int)); pointcount_index=12;}
#line 1697 "y.tab.c" /* yacc.c:1652  */
    break;

  case 13:
#line 168 "defs.y" /* yacc.c:1652  */
    { extern struct tree *decisiontree; decisiontree = (yyvsp[0].y_tree); }
#line 1703 "y.tab.c" /* yacc.c:1652  */
    break;

  case 14:
#line 170 "defs.y" /* yacc.c:1652  */
    { extern struct tree *decisiontree; decisiontree = (yyvsp[0].y_tree); }
#line 1709 "y.tab.c" /* yacc.c:1652  */
    break;

  case 15:
#line 172 "defs.y" /* yacc.c:1652  */
    { new_var((yyvsp[-2].y_str), (yyvsp[0].y_tree)); }
#line 1715 "y.tab.c" /* yacc.c:1652  */
    break;

  case 16:
#line 174 "defs.y" /* yacc.c:1652  */
    { extern struct action *actionlist; actionlist = (yyvsp[0].y_action); }
#line 1721 "y.tab.c" /* yacc.c:1652  */
    break;

  case 19:
#line 183 "defs.y" /* yacc.c:1652  */
    { predeal_compass = (yyvsp[0].y_int);}
#line 1727 "y.tab.c" /* yacc.c:1652  */
    break;

  case 21:
#line 184 "defs.y" /* yacc.c:1652  */
    {bias_deal((yyvsp[-5].y_int),(yyvsp[-3].y_int),(yyvsp[0].y_int));}
#line 1733 "y.tab.c" /* yacc.c:1652  */
    break;

  case 22:
#line 189 "defs.y" /* yacc.c:1652  */
    { predeal_holding(predeal_compass, (yyvsp[0].y_str)); }
#line 1739 "y.tab.c" /* yacc.c:1652  */
    break;

  case 23:
#line 191 "defs.y" /* yacc.c:1652  */
    { predeal_holding(predeal_compass, (yyvsp[0].y_str)); }
#line 1745 "y.tab.c" /* yacc.c:1652  */
    break;

  case 25:
#line 197 "defs.y" /* yacc.c:1652  */
    { pointcount(pointcount_index, (yyvsp[0].y_int));
                  pointcount_index--;
                }
#line 1753 "y.tab.c" /* yacc.c:1652  */
    break;

  case 27:
#line 205 "defs.y" /* yacc.c:1652  */
    { extern int use_compass[NSUITS]; use_compass[(yyvsp[0].y_int)] = 1; (yyval.y_int)= (yyvsp[0].y_int); }
#line 1759 "y.tab.c" /* yacc.c:1652  */
    break;

  case 28:
#line 210 "defs.y" /* yacc.c:1652  */
    { extern int use_vulnerable[NSUITS]; use_vulnerable[(yyvsp[0].y_int)] = 1; (yyval.y_int)= (yyvsp[0].y_int); }
#line 1765 "y.tab.c" /* yacc.c:1652  */
    break;

  case 29:
#line 215 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = 0; }
#line 1771 "y.tab.c" /* yacc.c:1652  */
    break;

  case 30:
#line 217 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = 0; }
#line 1777 "y.tab.c" /* yacc.c:1652  */
    break;

  case 31:
#line 219 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = 0; }
#line 1783 "y.tab.c" /* yacc.c:1652  */
    break;

  case 32:
#line 221 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = 1; }
#line 1789 "y.tab.c" /* yacc.c:1652  */
    break;

  case 33:
#line 226 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = 0; }
#line 1795 "y.tab.c" /* yacc.c:1652  */
    break;

  case 34:
#line 228 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = 1; }
#line 1801 "y.tab.c" /* yacc.c:1652  */
    break;

  case 36:
#line 235 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = - (yyvsp[0].y_int); }
#line 1807 "y.tab.c" /* yacc.c:1652  */
    break;

  case 37:
#line 237 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = d2n((yyvsp[0].y_distr)); }
#line 1813 "y.tab.c" /* yacc.c:1652  */
    break;

  case 40:
#line 246 "defs.y" /* yacc.c:1652  */
    { insertshape((yyvsp[0].y_distr), (yyvsp[-1].y_int), (yyvsp[-2].y_int)); }
#line 1819 "y.tab.c" /* yacc.c:1652  */
    break;

  case 43:
#line 256 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_NUMBER, NIL, NIL, (yyvsp[0].y_int), 0); }
#line 1825 "y.tab.c" /* yacc.c:1652  */
    break;

  case 44:
#line 258 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = var_lookup((yyvsp[0].y_str), 1); }
#line 1831 "y.tab.c" /* yacc.c:1652  */
    break;

  case 45:
#line 260 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_LENGTH, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1837 "y.tab.c" /* yacc.c:1652  */
    break;

  case 46:
#line 262 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_HCPTOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1843 "y.tab.c" /* yacc.c:1652  */
    break;

  case 47:
#line 264 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_HCP, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1849 "y.tab.c" /* yacc.c:1652  */
    break;

  case 48:
#line 266 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT0TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1855 "y.tab.c" /* yacc.c:1652  */
    break;

  case 49:
#line 268 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT0, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1861 "y.tab.c" /* yacc.c:1652  */
    break;

  case 50:
#line 270 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT1TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1867 "y.tab.c" /* yacc.c:1652  */
    break;

  case 51:
#line 272 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT1, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1873 "y.tab.c" /* yacc.c:1652  */
    break;

  case 52:
#line 274 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT2TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1879 "y.tab.c" /* yacc.c:1652  */
    break;

  case 53:
#line 276 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT2, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1885 "y.tab.c" /* yacc.c:1652  */
    break;

  case 54:
#line 278 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT3TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1891 "y.tab.c" /* yacc.c:1652  */
    break;

  case 55:
#line 280 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT3, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1897 "y.tab.c" /* yacc.c:1652  */
    break;

  case 56:
#line 282 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT4TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1903 "y.tab.c" /* yacc.c:1652  */
    break;

  case 57:
#line 284 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT4, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1909 "y.tab.c" /* yacc.c:1652  */
    break;

  case 58:
#line 286 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT5TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1915 "y.tab.c" /* yacc.c:1652  */
    break;

  case 59:
#line 288 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT5, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1921 "y.tab.c" /* yacc.c:1652  */
    break;

  case 60:
#line 290 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT6TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1927 "y.tab.c" /* yacc.c:1652  */
    break;

  case 61:
#line 292 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT6, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1933 "y.tab.c" /* yacc.c:1652  */
    break;

  case 62:
#line 294 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT7TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1939 "y.tab.c" /* yacc.c:1652  */
    break;

  case 63:
#line 296 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT7, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1945 "y.tab.c" /* yacc.c:1652  */
    break;

  case 64:
#line 298 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT8TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1951 "y.tab.c" /* yacc.c:1652  */
    break;

  case 65:
#line 300 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT8, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1957 "y.tab.c" /* yacc.c:1652  */
    break;

  case 66:
#line 302 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT9TOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1963 "y.tab.c" /* yacc.c:1652  */
    break;

  case 67:
#line 304 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_PT9, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1969 "y.tab.c" /* yacc.c:1652  */
    break;

  case 68:
#line 306 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_LOSERTOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1975 "y.tab.c" /* yacc.c:1652  */
    break;

  case 69:
#line 308 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_LOSER, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1981 "y.tab.c" /* yacc.c:1652  */
    break;

  case 70:
#line 310 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CONTROLTOTAL, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1987 "y.tab.c" /* yacc.c:1652  */
    break;

  case 71:
#line 312 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CONTROL, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 1993 "y.tab.c" /* yacc.c:1652  */
    break;

  case 72:
#line 314 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CCCC, NIL, NIL, (yyvsp[-1].y_int), 0); }
#line 1999 "y.tab.c" /* yacc.c:1652  */
    break;

  case 73:
#line 316 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_QUALITY, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 2005 "y.tab.c" /* yacc.c:1652  */
    break;

  case 74:
#line 318 "defs.y" /* yacc.c:1652  */
    {
		  (yyval.y_tree) = newtree(TRT_SHAPE, NIL, NIL, (yyvsp[-3].y_int), 1<<(shapeno++));
		  if (shapeno >= 32) {
		    yyerror("Too many shapes -- only 32 allowed!\n");
		    YYERROR;
		  }
		}
#line 2017 "y.tab.c" /* yacc.c:1652  */
    break;

  case 75:
#line 326 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_HASCARD, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 2023 "y.tab.c" /* yacc.c:1652  */
    break;

  case 76:
#line 328 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_TRICKS, NIL, NIL, (yyvsp[-3].y_int), (yyvsp[-1].y_int)); }
#line 2029 "y.tab.c" /* yacc.c:1652  */
    break;

  case 77:
#line 330 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_TRICKS, NIL, NIL, (yyvsp[-3].y_int), 4); }
#line 2035 "y.tab.c" /* yacc.c:1652  */
    break;

  case 78:
#line 332 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_SCORE, (yyvsp[-1].y_tree), NIL, (yyvsp[-5].y_int), (yyvsp[-3].y_int)); }
#line 2041 "y.tab.c" /* yacc.c:1652  */
    break;

  case 79:
#line 334 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_IMPS, (yyvsp[-1].y_tree), NIL, 0, 0); }
#line 2047 "y.tab.c" /* yacc.c:1652  */
    break;

  case 80:
#line 336 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = (yyvsp[-1].y_tree); }
#line 2053 "y.tab.c" /* yacc.c:1652  */
    break;

  case 81:
#line 338 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CMPEQ, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2059 "y.tab.c" /* yacc.c:1652  */
    break;

  case 82:
#line 340 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CMPNE, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2065 "y.tab.c" /* yacc.c:1652  */
    break;

  case 83:
#line 342 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CMPLT, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2071 "y.tab.c" /* yacc.c:1652  */
    break;

  case 84:
#line 344 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CMPLE, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2077 "y.tab.c" /* yacc.c:1652  */
    break;

  case 85:
#line 346 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CMPGT, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2083 "y.tab.c" /* yacc.c:1652  */
    break;

  case 86:
#line 348 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_CMPGE, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2089 "y.tab.c" /* yacc.c:1652  */
    break;

  case 87:
#line 350 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_AND2, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2095 "y.tab.c" /* yacc.c:1652  */
    break;

  case 88:
#line 352 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_OR2, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2101 "y.tab.c" /* yacc.c:1652  */
    break;

  case 89:
#line 354 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_ARPLUS, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2107 "y.tab.c" /* yacc.c:1652  */
    break;

  case 90:
#line 356 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_ARMINUS, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2113 "y.tab.c" /* yacc.c:1652  */
    break;

  case 91:
#line 358 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_ARTIMES, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2119 "y.tab.c" /* yacc.c:1652  */
    break;

  case 92:
#line 360 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_ARDIVIDE, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2125 "y.tab.c" /* yacc.c:1652  */
    break;

  case 93:
#line 362 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_ARMOD, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0); }
#line 2131 "y.tab.c" /* yacc.c:1652  */
    break;

  case 94:
#line 364 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_IF, (yyvsp[-4].y_tree), newtree(TRT_THENELSE, (yyvsp[-2].y_tree), (yyvsp[0].y_tree), 0, 0), 0, 0); }
#line 2137 "y.tab.c" /* yacc.c:1652  */
    break;

  case 95:
#line 366 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_NOT, (yyvsp[0].y_tree), NIL, 0, 0); }
#line 2143 "y.tab.c" /* yacc.c:1652  */
    break;

  case 96:
#line 368 "defs.y" /* yacc.c:1652  */
    { (yyval.y_tree) = newtree(TRT_RND, (yyvsp[-1].y_tree), NIL, 0, 0); }
#line 2149 "y.tab.c" /* yacc.c:1652  */
    break;

  case 97:
#line 373 "defs.y" /* yacc.c:1652  */
    { (yyval.y_expr) = newexpr((yyvsp[0].y_tree), 0, 0); }
#line 2155 "y.tab.c" /* yacc.c:1652  */
    break;

  case 98:
#line 375 "defs.y" /* yacc.c:1652  */
    { (yyval.y_expr) = newexpr(0, (yyvsp[0].y_str), 0); }
#line 2161 "y.tab.c" /* yacc.c:1652  */
    break;

  case 99:
#line 377 "defs.y" /* yacc.c:1652  */
    { (yyval.y_expr) = newexpr((yyvsp[0].y_tree), 0, (yyvsp[-2].y_expr)); }
#line 2167 "y.tab.c" /* yacc.c:1652  */
    break;

  case 100:
#line 379 "defs.y" /* yacc.c:1652  */
    { (yyval.y_expr) = newexpr(0, (yyvsp[0].y_str), (yyvsp[-2].y_expr)); }
#line 2173 "y.tab.c" /* yacc.c:1652  */
    break;

  case 101:
#line 384 "defs.y" /* yacc.c:1652  */
    { (yyval.y_action) = (yyvsp[0].y_action); }
#line 2179 "y.tab.c" /* yacc.c:1652  */
    break;

  case 102:
#line 386 "defs.y" /* yacc.c:1652  */
    { (yyval.y_action) = (yyvsp[-2].y_action); (yyval.y_action)->ac_next = (yyvsp[0].y_action); }
#line 2185 "y.tab.c" /* yacc.c:1652  */
    break;

  case 103:
#line 388 "defs.y" /* yacc.c:1652  */
    { (yyval.y_action) = 0; }
#line 2191 "y.tab.c" /* yacc.c:1652  */
    break;

  case 104:
#line 392 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action) = newaction(ACT_PRINTALL, NIL, (char *) 0, 0, NIL);
                }
#line 2199 "y.tab.c" /* yacc.c:1652  */
    break;

  case 105:
#line 396 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action) = newaction(ACT_PRINTEW, NIL, (char *) 0, 0, NIL);
                }
#line 2207 "y.tab.c" /* yacc.c:1652  */
    break;

  case 106:
#line 400 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action) = newaction(ACT_PRINT, NIL, (char *) 0, (yyvsp[-1].y_int), NIL);
                }
#line 2215 "y.tab.c" /* yacc.c:1652  */
    break;

  case 107:
#line 404 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action)=newaction(ACT_PRINTCOMPACT,NIL,0,0, NIL);}
#line 2222 "y.tab.c" /* yacc.c:1652  */
    break;

  case 108:
#line 407 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action) = newaction(ACT_PRINTONELINE, NIL, 0, 0, NIL);}
#line 2229 "y.tab.c" /* yacc.c:1652  */
    break;

  case 109:
#line 410 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action)=newaction(ACT_PRINTPBN,NIL,0,0, NIL);}
#line 2236 "y.tab.c" /* yacc.c:1652  */
    break;

  case 110:
#line 413 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action)=newaction(ACT_PRINTES,(struct tree*)(yyvsp[-1].y_expr),0,0, NIL); }
#line 2243 "y.tab.c" /* yacc.c:1652  */
    break;

  case 111:
#line 416 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action)=newaction(ACT_EVALCONTRACT,0,0,0, NIL);}
#line 2250 "y.tab.c" /* yacc.c:1652  */
    break;

  case 112:
#line 419 "defs.y" /* yacc.c:1652  */
    { will_print++; 
                  (yyval.y_action)=newaction(ACT_PRINTCOMPACT,(yyvsp[-1].y_tree),0,0, NIL);}
#line 2257 "y.tab.c" /* yacc.c:1652  */
    break;

  case 113:
#line 422 "defs.y" /* yacc.c:1652  */
    { will_print++;
                  (yyval.y_action)=newaction(ACT_PRINTONELINE,(yyvsp[-1].y_tree),0,0, NIL);}
#line 2264 "y.tab.c" /* yacc.c:1652  */
    break;

  case 114:
#line 425 "defs.y" /* yacc.c:1652  */
    { (yyval.y_action) = newaction(ACT_AVERAGE, (yyvsp[0].y_tree), (yyvsp[-1].y_str), 0, NIL); }
#line 2270 "y.tab.c" /* yacc.c:1652  */
    break;

  case 115:
#line 427 "defs.y" /* yacc.c:1652  */
    { (yyval.y_action) = newaction(ACT_FREQUENCY, (yyvsp[-5].y_tree), (yyvsp[-7].y_str), 0, NIL);
                  (yyval.y_action)->ac_u.acu_f.acuf_lowbnd = (yyvsp[-3].y_int);
                  (yyval.y_action)->ac_u.acu_f.acuf_highbnd = (yyvsp[-1].y_int);}
#line 2278 "y.tab.c" /* yacc.c:1652  */
    break;

  case 116:
#line 431 "defs.y" /* yacc.c:1652  */
    {
             (yyval.y_action) = newaction(ACT_FREQUENCY2D, (yyvsp[-11].y_tree), (yyvsp[-13].y_str), 0, (yyvsp[-5].y_tree));
             (yyval.y_action)->ac_u.acu_f2d.acuf_lowbnd_expr1 = (yyvsp[-9].y_int);
             (yyval.y_action)->ac_u.acu_f2d.acuf_highbnd_expr1 = (yyvsp[-7].y_int);
             (yyval.y_action)->ac_u.acu_f2d.acuf_lowbnd_expr2 = (yyvsp[-3].y_int);
             (yyval.y_action)->ac_u.acu_f2d.acuf_highbnd_expr2 = (yyvsp[-1].y_int);
                }
#line 2290 "y.tab.c" /* yacc.c:1652  */
    break;

  case 117:
#line 441 "defs.y" /* yacc.c:1652  */
    { (yyval.y_str) = (char *) 0; }
#line 2296 "y.tab.c" /* yacc.c:1652  */
    break;

  case 118:
#line 443 "defs.y" /* yacc.c:1652  */
    { (yyval.y_str) = (yyvsp[0].y_str); }
#line 2302 "y.tab.c" /* yacc.c:1652  */
    break;

  case 119:
#line 447 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = (1<<(yyvsp[0].y_int)); }
#line 2308 "y.tab.c" /* yacc.c:1652  */
    break;

  case 120:
#line 449 "defs.y" /* yacc.c:1652  */
    { (yyval.y_int) = (yyvsp[-2].y_int)|(1<<(yyvsp[0].y_int)); }
#line 2314 "y.tab.c" /* yacc.c:1652  */
    break;


#line 2318 "y.tab.c" /* yacc.c:1652  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;


#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif


/*-----------------------------------------------------.
| yyreturn -- parsing is finished, return the result.  |
`-----------------------------------------------------*/
yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 451 "defs.y" /* yacc.c:1918  */


struct var {
        struct var *v_next;
        char *v_ident;
        struct tree *v_tree;
} *vars=0;

struct tree *var_lookup(char *s, int mustbethere)
{
        struct var *v;

        for(v=vars; v!=0; v = v->v_next)
                if (strcmp(s, v->v_ident)==0)
                        return v->v_tree;
        if (mustbethere)
                yyerror("unknown variable");
        return 0;
}

void new_var(char *s, struct tree *t)
{
        struct var *v;
        /* char *mycalloc(); */

        if (var_lookup(s, 0)!=0)
                yyerror("redefined variable");
        v = (struct var *) mycalloc(1, sizeof(*v));
        v->v_next = vars;
        v->v_ident = s;
        v->v_tree = t;
        vars = v;
}

int lino=1;

void yyerror( char *s) {
        fprintf(stderr, "line %d: %s\n", lino, s);
        exit(-1);
}

int perm[24][4] = {
        {       0,      1,      2,      3       },
        {       0,      1,      3,      2       },
        {       0,      2,      1,      3       },
        {       0,      2,      3,      1       },
        {       0,      3,      1,      2       },
        {       0,      3,      2,      1       },
        {       1,      0,      2,      3       },
        {       1,      0,      3,      2       },
        {       1,      2,      0,      3       },
        {       1,      2,      3,      0       },
        {       1,      3,      0,      2       },
        {       1,      3,      2,      0       },
        {       2,      0,      1,      3       },
        {       2,      0,      3,      1       },
        {       2,      1,      0,      3       },
        {       2,      1,      3,      0       },
        {       2,      3,      0,      1       },
        {       2,      3,      1,      0       },
        {       3,      0,      1,      2       },
        {       3,      0,      2,      1       },
        {       3,      1,      0,      2       },
        {       3,      1,      2,      0       },
        {       3,      2,      0,      1       },
        {       3,      2,      1,      0       },
};

int shapeno;
void insertshape(s, any, neg_shape)
char s[4];
{
        int i,j,p;
        int xcount=0, ccount=0;
        char copy_s[4];

        for (i=0;i<4;i++) {
		if (s[i]=='x')
                        xcount++;
                else
                        ccount += s[i]-'0';
        }
        switch(xcount) {
        case 0:
                if (ccount!=13)
                        yyerror("wrong number of cards in shape");
                for (p=0; p<(any? 24 : 1); p++)
                        setshapebit(s[perm[p][3]]-'0', s[perm[p][2]]-'0',
                                s[perm[p][1]]-'0', s[perm[p][0]]-'0',
                                1<<shapeno, neg_shape);
                break;
        default:
                if (ccount>13)
                        yyerror("too many cards in ambiguous shape");
                bcopy(s, copy_s, 4);
                for(i=0; copy_s[i] != 'x'; i++)
                        ;
                if (xcount==1) {
                        copy_s[i] = 13-ccount+'0';      /* could go above '9' */
                        insertshape(copy_s, any, neg_shape);
                } else {
                        for (j=0; j<=13-ccount; j++) {
                                copy_s[i] = j+'0';
                                insertshape(copy_s, any, neg_shape);
                        }
                }
                break;
        }
}

int d2n(char s[4]) {
        static char copys[5];

        strncpy(copys, s, 4);
        return atoi(copys);
}

struct tree *newtree(type, p1, p2, i1, i2)
int type;
struct tree *p1, *p2;
int i1,i2;
{
        /* char *mycalloc(); */
        struct tree *p;

        p = (struct tree *) mycalloc(1, sizeof(*p));
        p->tr_type = type;
        p->tr_leaf1 = p1;
        p->tr_leaf2 = p2;
        p->tr_int1 = i1;
        p->tr_int2 = i2;
        return p;
}

struct action *newaction(type, p1, s1, i1, p2)
int type;
struct tree *p1;
char *s1;
int i1;
struct tree *p2;
{
        /* char *mycalloc(); */
        struct action *a;

        a = (struct action *) mycalloc(1, sizeof(*a));
        a->ac_type = type;
        a->ac_expr1 = p1;
        a->ac_str1 = s1;
        a->ac_int1 = i1;
        a->ac_expr2 = p2;
        return a;
}

struct expr *newexpr(struct tree* tr1, char* ch1, struct expr* ex1)
{
    struct expr* e;
    e=(struct expr*) mycalloc(1, sizeof(*e));
    e->ex_tr = tr1;
    e->ex_ch = ch1;
    e->next  = 0;
    if(ex1) {
        struct expr* exau = ex1;
            /* AM990705: the while's body had mysteriously disappeared, reinserted it */
            while(exau->next)
              exau = exau->next;
            exau->next = e;
            return ex1;
    } else {
        return e;
    }
}

char *mystrcpy(s)
char *s;
{
        char *cs;
        /* char *mycalloc(); */

        cs = mycalloc(strlen(s)+1, sizeof(char));
        strcpy(cs, s);
        return cs;
}

void predeal_holding(compass, holding)
char *holding;
{
        char suit;

        suit = *holding++;
        while (*holding) {
                predeal(compass, make_card(*holding, suit));
                holding++;
        }
}


#define TRUNCZ(x) ((x)<0?0:(x))

extern int biasdeal[4][4];
extern char*player_name[4];
static char *suit_name[] = {"Club", "Diamond", "Heart", "Spade"};


int bias_len(int compass){
  return
    TRUNCZ(biasdeal[compass][0])+
    TRUNCZ(biasdeal[compass][1])+
    TRUNCZ(biasdeal[compass][2])+
    TRUNCZ(biasdeal[compass][3]);
}

int bias_totsuit(int suit){
  return
    TRUNCZ(biasdeal[0][suit])+
    TRUNCZ(biasdeal[1][suit])+
    TRUNCZ(biasdeal[2][suit])+
    TRUNCZ(biasdeal[3][suit]);
}

void bias_deal(int suit, int compass, int length){
  if(biasdeal[compass][suit]!=-1){
    char s[256];
    sprintf(s,"%s's %s suit has length already set to %d",
      player_name[compass],suit_name[suit],
      biasdeal[compass][suit]);
    yyerror(s);
  }
  biasdeal[compass][suit]=length;
  if(bias_len(compass)>13){
      char s[256];
    sprintf(s,"Suit lengths too long for %s",
      player_name[compass]);
    yyerror(s);
  }
  if(bias_totsuit(suit)>13){
    char s[256];
    sprintf(s,"Too many %ss",suit_name[suit]);
    yyerror(s);
  }
}


#define YY_USE_PROTOS

#ifdef WIN32
#pragma warning( disable : 4127 )
#endif

#include "scan.c"

#ifdef WIN32
#pragma warning( default : 4127 )
#endif


